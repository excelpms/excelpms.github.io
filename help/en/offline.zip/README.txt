PMS ENGLISH HELP MANUAL — OFFLINE EDITION

Getting started
1. Extract the entire ZIP file to a local folder.
2. Open PMS_Help_Manual_English.html in Microsoft Edge, Chrome or another modern browser.
3. Keep the assets folder beside the HTML file. It contains the manual's screenshots.

No internet connection, installation or web server is required.
The search box searches all chapter and appendix text locally. Enter a button name,
Token, error message or topic. Multiple words narrow the results. Press Escape to
clear the search. Click a result or Contents entry to navigate to that section.
Click a screenshot to view it at full size.

Contents
Complete English edition: Preface, 21 chapters and 6 appendices, with configuration
references, worked examples, troubleshooting, a command index and 17 screenshots.
The accompanying Word and PDF editions contain the same manual content. They are
provided separately so they can be downloaded and used independently.

Screenshots show an example workbook. Project names, column positions, parameter
numbers and interface layouts can differ in a customized project. Follow the
field names and Tokens explained in the manual and use the current PMS workbook
as the authority for its available functions and configuration.

Edition date: 11 October 2026
